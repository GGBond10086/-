import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '@/views/LoginView.vue'

const routes = [
  {
    path: '/',
    name: 'login',
    component: LoginView
  },
  {
    path: '/duser',
    name: 'duser',
    component: () => import('../components/Duser'),
    children: [
      {
        path:'',
        component: () => import('../views/Welcome')
      },
      {
        path:'user',
        component: () => import('../views/User')
      },
      
      {
        path:'derivative',
        component: () => import('../views/Derivative')
      },
      {
        path:'derivativeuser',
        component: () => import('../views/DerivativeUser')
      },
      {
        path:'risk',
        component: () => import('../views/Risk')
      },
        {
          path:'userinfo',
          component:()=>import('../views/UserInfo')
        }
      
    ]
  },
  {
    path: '/dadmin',
    name: 'dadmin',
    component: () => import('../components/Dadmin'),
    children: [
      {
        path:'',
        component: () => import('../views/Welcome')
      },
      {
        path:'user',
        component: () => import('../views/User')
      },
      {
        path:'derivative',
        component: () => import('../views/Derivative')
      },
      {
        path:'risk',
        component: () => import('../views/Risk')
      }
      
    ]
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
