<template>
  <div style="padding: 15px">
    <br />
    <br />

    <el-form :model="user" label-width="120px">
      <el-form-item label="用户Id">
          <!-- <el-input v-model="form.username" /> -->
          {{ user.userId }}
        </el-form-item>
        <el-form-item label="用户账号">
          <!-- <el-input v-model="form.username" /> -->
          {{ user.username }}
        </el-form-item>
      
        <el-form-item label="用户手机号">
          <!-- <el-input v-model="form.username" /> -->
          {{ user.phone }}
        </el-form-item>
       
        <el-form-item label="金额">
          <!-- <el-input v-model="form.username" /> -->
          {{ user.money }}
        </el-form-item>

        <el-form-item label="操作">
          <el-button  @click="dialogFormVisibleUpdate=true">修改</el-button>

        </el-form-item>
    </el-form>
   
  </div>


  <el-dialog
    v-model="dialogFormVisibleUpdate"
           center
           title="修改"
           draggable
      @close="handleClose"
           >
    <el-form :model="user" label-width="120px">
        <el-form-item label="用户名" prop="username">
            <el-input v-model="user.username"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
            <el-input type="password" v-model="user.password"></el-input>
        </el-form-item>
        <el-form-item label="手机号码" prop="phone">
            <el-input v-model="user.phone"></el-input>
        </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisibleUpdate=false">取消</el-button>
        <el-button type="primary" @click="update">确定修改</el-button>
    </span>
</el-dialog>

</template>
   
   <script>
import { reactive, toRefs } from "vue";
import http from "@/utils/http";
import { ElMessage } from "element-plus";
import axios from "axios";
import {useRouter} from "vue-router";

export default {
  name: "User",
  setup() {
    const data = reactive({
      user: {
        state: 1,
      },
      //表单的内容
      total: 10, //分页总条数
      pageNum: 1, //当前页
      pageSize: 5, //初始化每页大小
      dialogFormVisible: false, //对话框的显示和隐藏
      dialogFormVisibleUpdate: false, //对话框的显示和隐藏
      dialogAdd: false,
      user:{
      },
      user1:{
      }

    });

        //读取存储的用户信息
    let user1 = sessionStorage.getItem('user');
    if(!(user1 == null || user1 == '')){
      data.user1 = JSON.parse(user1);
    }

    //查看的方法
    const show = function () {
      // alert(row.userId);//row对应list中的json对象
    // data.dialogFormVisible = true;
    http.get('/api/user/show/'+data.user1.userId,{}).then(function(res){
      data.user=res.data;
    })
    };
    show();

    const update = function() {
      http.post('/api/user/update',data.user).then(function(res){
        if(res.code==1){
          ElMessage({
            message: "修改成功!",
            type: "success",
          });
          data.dialogFormVisibleUpdate = false;
        }else{
          ElMessage.error("修改失败!");
        }
      });
    }

    //删除用户数据
    const handleDelete = function() {
      http.get('/api/user/delete/'+data.user.userId).then(function(res){
        if(res.code==1){
          alert("删除成功！"),
          ElMessage({
            message: "删除成功!",
            type: "success",
          });
          sessionStorage.clear()
          router.push("/")
        }else{
          ElMessage.error("删除失败!");
        }
      });

    };

    return {
      ...toRefs(data),
      show,
      handleDelete,
      update,
    };
  },
};
</script>
   
   <style scoped>
</style>