<template>
    <div style="padding: 15px">
      <br />
      <!--表单 -->
      <el-form :inline="true" :model="derivative" class="demo-form-inline">
        <el-form-item label="id">
          <el-input v-model="derivative.derivative_id" placeholder="精准匹配" clearable />
        </el-form-item>
        <el-form-item label="名称">
          <el-input v-model="derivative.derivative_name" placeholder="模糊匹配" clearable />
        </el-form-item>
  
        <el-form-item>
          <el-button type="primary" @click="load">快捷查询</el-button>
        </el-form-item>
      </el-form>
      
      <!--表格 -->
      <el-table :data="list" stripe border style="width: 100%">
        <el-table-column type="index" width="80" align="center" label="序号" />
        <el-table-column prop="derivativeId" align="center" label="编号" />
        <el-table-column prop="derivativeName" align="center" label="名称" />
        <el-table-column prop="price" align="center" label="价格" />
        <el-table-column prop="createTime" align="center" label="创建日期" />
        <el-table-column prop="updateTime" align="center" label="更新日期" />
        <el-table-column prop="type" align="center" label="类型" />
        <el-table-column prop="derivativeQuantity" align="center" label="库存" />

        <el-table-column label="操作" align="center">
          <template #default="scope">
            <el-button round size="small" @click="show(scope.row)" type="success">下单</el-button>

          </template>
        </el-table-column>
      </el-table>
      <br />
      <!--分页 -->
      <el-pagination background v-model:current-page="pageNum" :page-sizes="[5, 10, 15, 20]" :small="small" :pageSize="pageSize"
        :disabled="disabled" layout="prev, pager, next" :total="total" @current-change="handleCurrentChange" />

        <!-- 查看数据的对话框 -->
      <el-dialog v-model="dialogShowVisible" :title="'查看期货'" draggable @close="handleClose">
        <el-form :model="order" label-width="120px">
          <el-form-item label="用户ID">
            {{order.userId}}
          </el-form-item>
          <el-form-item label="编号">
            {{order.derivativeId}}
          </el-form-item>
          <el-form-item label="名称">
            {{order.derivativeName}}
          </el-form-item>
          <el-form-item label="库存">
            {{ order.derivativeQuantity-order.num }}
          </el-form-item>
          <el-form-item label="价格">
            <el-input disabled="true"v-model.number="order.price" />
          </el-form-item>
          <el-form-item label="类型">
            {{order.type}}
          </el-form-item>
          <el-form-item label="买入数量">
            <el-input v-model.number="order.num" />
          </el-form-item>
          <el-form-item label="总价" >
           <el-input disabled="true"  v-model="computedSumPrice"  />
          </el-form-item>
        </el-form>
        <template #footer>
          <span class="dialog-footer">
            <el-button type="primary" @click="bill"> 下单 </el-button>
          </span>
        </template>
      </el-dialog>
    </div>
  </template>
  
  <script>
  import { reactive, toRefs } from "vue";
  import http from "@/utils/http";
  import { ElMessage } from "element-plus";
  import axios from "axios";
  import { computed } from 'vue';
  export default {
    name: "derivative",
    setup() {
      const data = reactive({
        form: {
          state: 1,
        }, //表单的内容
        price:1,
        list: [], //表格的内容
        total: 10, //分页总条数
        pageNum: 1, //当前页
        pageSize: 1, //初始化每页大小
        // dialogFormVisible: false, //对话框的显示和隐藏
        dialogShowVisible: false, //对话框的显示和隐藏
        derivative:{
          derivativeQuantity:11,
          derivative_id:"",
          derivative_name:"",
          // price:"",
          // createTime:"",
          // updateTime:"",
          // type:"",
          // derivativeQuantity:""
       },
       order:{
        num:1,
        userid:1,
        price:6,
        computedSumPrice:12,
       }
      });
  
    //   const result = reactive({
    //     code: 0,
    //     msg: "hh"
    //   });
      // const userdata=reactive({
       
      // });
      const reld = () => {
        window.location.reload();
      }
      //分页查询
      const load = () => {
        http.get("/api/derivative/wlist/"+data.pageNum, {
            params: {
              id:data.derivative.derivative_id,
              name:data.derivative.derivative_name
            },
          })
          .then(function (res) {
            data.list = res.data.list;
            data.pageNum = res.data.pageNum;
            data.total = res.data.total;
            data.pageSize=res.data.pageSize;
          });
      };
      // if()
      load();//调用加载
  
    //   //点击增加按钮
    //   const add = function () {
    //     data.dialogFormVisible = true;
    //   };
      //查看的方法
      const show = function (row) {
        // alert(row.userId);//row对应list中的json对象
        //对话框关闭
        data.dialogShowVisible = true;
        data.order=row;
      };

      const bill=function () {
        data.order.computedSumPrice=data.order.price*data.order.num
        http.post("/api/order/bill",data.order).then((res)=>{
          if(res.code==200){
            ElMessage({
              message: "增加成功!",
              type: "success",
            });
            data.dialogShowVisible = false;
          }else{
            ElMessage({
              message: "增加失败!",
              type: "error",
            });
          }
        });
        reld()
      }
      

    const computedSumPrice = computed(() => data.order.num * data.order.price);

      const handleCurrentChange=function(){
        // alert(data.pageNum)
        load();
      }
  
      return {
        ...toRefs(data),
        load,
        handleCurrentChange,
        computedSumPrice,
        show,
        bill
      };
    },
  };

  </script>
  
  <style scoped></style>