<template>
  <div style="padding: 15px">
    <!--增加按钮 -->
    <el-button type="success" @click="add">增加衍生品</el-button>
    <br />
    <br />
    <!--表单 -->
    <el-form :inline="true" :model="serarch" class="demo-form-inline">
      <el-form-item label="衍生品ID">
        <el-input v-model="serarch.derivativeId" placeholder="精准匹配" clearable />
      </el-form-item>
      <el-form-item label="衍生品名">
        <el-input v-model="serarch.derivativeName" placeholder="模糊匹配" clearable />
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="load">快捷查询</el-button>
      </el-form-item>
    </el-form>

    <!--表格 -->
    <el-table :data="list" border style="width: 100%">
      <el-table-column type="index" width="80" align="center" label="序号" />
      <el-table-column prop="derivativeId" align="center" label="衍生品ID" />
      <el-table-column prop="derivativeName" align="center" label="衍生品名" />
      <el-table-column prop="price" align="center" label="衍生品单价" />
      <el-table-column prop="createTime" align="center" label="创建时间" />
      <el-table-column prop="updateTime" align="center" label="更新时间"/>
      <el-table-column prop="type" align="center" label="衍生品类型" />
      <el-table-column prop="derivativeQuantity" align="center" label="剩余库存"/>
      <!-- <el-table-column prop="isAu" align="center" label="认证" /> -->
        <!-- <template #default="scope">
          <el-button v-if="scope.row.derivativeStatus == 0" type="danger"style="color: red" @click="updatestatus(scope.row)">禁用</el-button>
          <el-button v-if="scope.row.derivativeStatus == 1" type="success" style="color: green"@click="updatestatus(scope.row)">启用</el-button>
        </template>
      </el-table-column> -->
      <el-table-column label="操作" align="center">
        <template #default="scope">
          <el-button size="small" type="primary"@click="update(scope.row)"
            >修改</el-button
          >

          <el-popconfirm
            title="你确定删除么?"
            @confirm="handleDelete(scope.row)"
          >
            <template #reference>
              <el-button size="small" type="danger">删除</el-button>
            </template>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>
    <br />
    <!--分页 -->
    <el-pagination
      background
      v-model:current-page="pageNum"
      :page-sizes="[5, 10, 15, 20]"
      :small="small"
      :disabled="disabled"
      v-model:pageSize="pageSize"
      layout="prev, pager, next"
      :total="total"
      @current-change="handleCurrentChange"
    />

    <!-- 增加数据的对话框 -->
    <el-dialog
      v-model="dialogFormVisibleAdd"
      :title="'增加衍生品'"
      draggable
      @close="handleClose"
    >
      <el-form :model="derivative" label-width="120px">
        <el-form-item label="衍生品名">
          <el-input v-model="derivative.derivativeName" />
        </el-form-item>
        <el-form-item label="衍生品单价">
          <el-input v-model="derivative.price" />
        </el-form-item>
        <el-form-item label="创建时间">
          <el-date-picker
            v-model="derivative.createTime"
            :picker-options="pickerOptions"
            type="datetime"
            placeholder="请选择时间"
            format="YYYY-MM-DD hh:mm:ss"
            value-format="YYYY-MM-DD hh:mm:ss"
          />
        </el-form-item>
        <el-form-item label="更新时间">
          <el-date-picker disabled="true"
            v-model="derivative.updateTime"
            type="datetime"
            placeholder="请选择时间"
            format="YYYY-MM-DD hh:mm:ss"
            value-format="YYYY-MM-DD hh:mm:ss"
          />
        </el-form-item>
        <el-form-item label="剩余库存">
          <el-input v-model="derivative.derivativeQuantity" />
        </el-form-item>
        <el-form-item label="衍生品类型">
          <el-radio-group v-model="derivative.type">
            <el-radio value="期货">期货</el-radio>
            <el-radio value="期权">期权</el-radio>
            <el-radio value="远期">远期</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleClose">取消</el-button>
          <el-button type="primary" @click="save"> 保存 </el-button>
        </span>
      </template>
    </el-dialog>
    <!-- 增加数据的对话框 -->
    <el-dialog
      v-model="dialogFormVisibleupdat"
      :title="'修改衍生品'"
      draggable
      @close="handleClose"
    >
      <el-form :model="derivative" label-width="120px">
        <el-form-item label="衍生品Id">
          <el-input disabled="true" v-model="derivative.derivativeId" />
        </el-form-item>
        <el-form-item label="衍生品名">
          <el-input v-model="derivative.derivativeName" />
        </el-form-item>
        <el-form-item label="衍生品单价">
          <el-input v-model="derivative.price" />
        </el-form-item>
        <el-form-item label="创建时间">
          <el-date-picker disabled="true"
            v-model="derivative.createTime"
            type="datetime"
            placeholder="请选择时间"
            format="YYYY-MM-DD hh:mm:ss"
            value-format="YYYY-MM-DD hh:mm:ss"
          />
        </el-form-item>
        <el-form-item label="更新时间">
          <el-date-picker
            v-model="derivative.updateTime"
            type="datetime"
            placeholder="请选择时间"
            format="YYYY-MM-DD hh:mm:ss"
            value-format="YYYY-MM-DD hh:mm:ss"
          />
        </el-form-item>
        <el-form-item label="剩余库存">
          <el-input v-model="derivative.derivativeQuantity" />
        </el-form-item>
        <el-form-item label="衍生品类型">
          <el-radio-group v-model="derivative.type">
            <el-radio value="期货">期货</el-radio>
            <el-radio value="期权">期权</el-radio>
            <el-radio value="远期">远期</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleClose">取消</el-button>
          <el-button type="primary" @click="updateover"> 保存 </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>
   
   <script>
import { reactive, toRefs } from "vue";
import http from "@/utils/http";
import { ElMessage } from "element-plus";
import axios from "axios";

export default {
  name: "derivative",
  setup() {
    const data = reactive({

      list: [], //表格的内容
      total: 10, //分页总条数
      pageNum: 1, //当前页
      pageSize: 5, //初始化每页大小
      dialogFormVisibleupdat: false, //对话框的显示和隐藏
      dialogFormVisibleAdd:false,
      derivative:{
        type:"期货",
      },
      serarch:{
        derivativeName:"",
        derivativeId:""
      },
    });
    //分页查询
    const load = () => {
      http
        .get("/api/derivative/list/"+data.pageNum, {
          params: {
            pageNum: 1, //当前页
            pageSize: 1, //每页大小
            total:10,
            derivativeId: data.serarch.derivativeId,
            derivativeName: data.serarch.derivativeName,
          },
        })
        .then(function(res){
          if(res.code==200)
      {
        ElMessage({
        message:res.msg,
        type: "success",
      });
      data.list=res.data.list;
      data.pageNum=res.data.pageNum;
      data.total=res.data.total;
        }else{
        ElMessage({
        message: res.msg,
        type: "error",
      });
      }
        });
    };
     load();//调用加载
    const save=function(){
      http
        .post(`/api/derivative/save/`,data.derivative)
        .then(function(res){
          if(res.code==200)
      {
        ElMessage({
        message:res.msg,
        type: "success",
      });
   
      data.dialogFormVisibleAdd = false;
      }else{
        ElMessage({
        message: res.msg,
        type: "error",
      });
      }
      load()
        });
    }
    //点击增加按钮
    const add = function () {
      data.dialogFormVisibleAdd = true;
    };
    //查看的方法
    const updateover=function(){
      http
        .post(`/api/derivative/update/`,data.derivative)
        .then(function(res){
          if(res.code==200)
      {
        ElMessage({
        message:res.msg,
        type: "success",
      });
  
      data.dialogFormVisibleupdat = false;
      }else{
        ElMessage({
        message: res.msg,
        type: "error",
      });
      }
      load()
        });
    };
    const update = function (row) {
      data.dialogFormVisibleupdat = true;
      data.derivative=row
    };

    //   //处理关闭对话框时数据清理
      const handleClose = () => {
        data.derivative = {type:"期货"}
        data.dialogFormVisibleupdat = false
        data.dialogFormVisibleAdd=false
      }

    //删除用户数据
    const handleDelete = function (row) {

      http
        .get(`/api/derivative/delete/`+row.derivativeId)
        .then(function(res){
          if(res.code==200)
      {
        ElMessage({
        message:res.msg,
        type: "success",
      });
     
      }else{
        ElMessage({
        message: res.msg,
        type: "error",
      });
      }
      load()
        });
      //删除完成更新数据

    };
const handleCurrentChange=function(){
  http
        .get(`/api/derivative/list/`+data.pageNum)
        .then(function(res){
      data.list=res.data.list;
      data.pageNum=res.data.pageNum;
      console.log(data.pageNum);
      data.total=res.data.total;
        });

};
    return {
      ...toRefs(data),
      load,
      handleClose,
      update,
      updateover,
      add,
      save,
      handleCurrentChange,
      handleDelete,
    };
  },
};
</script>
   
   <style scoped>
</style>