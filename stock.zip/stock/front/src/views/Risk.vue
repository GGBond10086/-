<template>
  <div class="chart-container">
    <div ref="chart" class="chart" v-if="isChartVisible"></div>
  </div>
  <br/>  <br/>
  <div align="center">
    <el-form :inline="true" :model="form">
      <el-form-item >
        <el-input size="large"  v-model="form.derivativeName" placeholder="请输入衍生品名称" clearable />
      </el-form-item>
      <el-form-item>
        <el-button size="large" type="primary" @click="showChart">查询风险</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import { ref,reactive, toRefs } from 'vue';
import axios from 'axios';
import * as echarts from 'echarts';

export default {
  setup() {
    const data = reactive({
      form: {
        derivativeName:"石油"
      }
      })
    const chartData = ref([]);
    const chart = ref(null);
    const isChartVisible = ref(false);

    const fetchChartData = async () => {
      try {
        const response = await axios.get('/api/risk/'+data.form.derivativeName);
        chartData.value = response.data.data;
        renderChart();
      } catch (error) {
        console.error("Error fetching chart data:", error);
      }
    };

    const renderChart = () => {
      if (!chartData.value.length) return;

      const chartDom = chart.value;
      const myChart = echarts.init(chartDom);

      const option = {
        title: {
          text: chartData.value[0].derivativeName + '风险参考',
          left: 'center',
          textStyle: {
            color: 'red', // 标题文本颜色
            fontSize: "30px",

          },
        },
        xAxis: {
          type: 'category',
          data: chartData.value.map(item => item.riskTime),
          show: true,
          axisLabel: {
            color: 'yellow', // X轴标签颜色
            fontSize: "18px",
          },
        },
        yAxis: {
          type: 'value',
          name: '￥(元)',
          nameTextStyle: {
            color: '#fff', // Y轴名称颜色
            fontSize: 20, // Y轴名称字体大小
          },
          axisLine: {
            lineStyle: {
              color: '#fff', // Y轴线颜色
            },
          },
          axisLabel: {
            color: '#fff', // Y轴标签颜色
            fontSize: "16px",

          },
        },
        series: [{
          data: chartData.value.map(item => item.riskPrice),
          type: 'line',
          smooth: false,
          symbolSize:5,
          lineStyle: {
            color: 'red', // 折线颜色
            width: 3,
          },
          itemStyle: {
            color: 'yellow', 
          }
        }],
      };

      myChart.setOption(option);
    };

    const showChart = () => {
      isChartVisible.value = true;
      fetchChartData();
    };

    return {
      ...toRefs(data),
      chart,
      chartData,
      isChartVisible,
      showChart,
      fetchChartData,
      renderChart
    };
  },
};
</script>

<style scoped>
.chart-container {
  width: 100%;
  height: 80%; /* 设置高度为固定值 */
  margin: 0 auto;
  border: 1px solid #ccc;
  border-radius: 5px;
  overflow: hidden;
  background-color: #000; /* 背景色为黑色 */
}

.chart {
  width: 100%;
  height: 100%;
}
</style>
