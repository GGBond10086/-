<template>
  <div class="welcome-message">
    欢迎使用金融衍生品系统 ，当前时间为: {{ currentTime }}
  </div>
</template>

<script>
export default {
  name: "Welcome",
  data() {
    return {
      currentTime: this.getCurrentTime()
    };
  },
  methods: {
    getCurrentTime() {
      const now = new Date();
      const year = now.getFullYear();
      const month = (now.getMonth() + 1).toString().padStart(2, '0'); // 月份从0开始
      const day = now.getDate().toString().padStart(2, '0');
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      const seconds = now.getSeconds().toString().padStart(2, '0');
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    },
    updateTime() {
      this.currentTime = this.getCurrentTime();
    }
  },
  mounted() {
    this.updateTime(); // 初始化时间
    this.timer = setInterval(this.updateTime, 1000); // 每秒更新一次时间
  },
  beforeDestroy() {
    clearInterval(this.timer); // 组件销毁前清除定时器
  }
};
</script>

<style scoped>
.welcome-message {
  width: 100%;
  font-size: 20px;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 30vh; /* 使 div 高度为视口高度，以实现垂直居中 */
  box-sizing: border-box; /* 包括内边距和边框在内的盒模型 */
  color: green;
}
</style>
