<template>
  <div class="login">
    <el-form class="login-form">

      <h2>登录</h2>

      <div class="form-group">
        <el-form-item label="账号">
        <el-input type="text" id="adminName" v-model="user.adminName" />
        </el-form-item>
        <el-form-item label="密码">
        <el-input type="password" id="password" v-model="user.password" />
        </el-form-item>
        <el-form-item label="用户类型">
          <el-radio-group v-model="user.userType">
            <el-radio :label="1" value="1">普通用户</el-radio>
            <el-radio :label="0" value="0">管理员</el-radio>
          </el-radio-group>
        </el-form-item>
      </div>
      <input type="button" @click="login" value="登录" class="login-button" />
      <br/><br/>
      <el-text >若无账号，请先<el-button type="success" @click="add(user.userType)">注册</el-button></el-text>
  
    </el-form>
      <!-- 用户注册的对话框 -->
    <el-dialog
      v-model="dialogFormVisible"
      :title="'用户注册'"
      draggable
      @close="handleClose"
    >
      <el-form :model="form" label-width="120px">
        <el-form-item label="账号">
          <el-input v-model="form.username" />
        </el-form-item>
        <el-form-item label="密码">
          <el-input v-model="form.password" type="password"/>
        </el-form-item>
        <el-form-item label="重复密码">
          <el-input v-model="form.repassword" type="password"/>
        </el-form-item>
        <el-form-item label="电话">
          <el-input v-model="form.phone"/>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleClose">取消</el-button>
          <el-button type="primary" @click="saveUser(form)"> 保存 </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { reactive, toRefs } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import http from "@/utils/http";


export default {
  name: "LoginView",
  setup() {
    //创建一个路由
    const router = useRouter();

    //变量
    const data = reactive({
      user: {
        adminName:"",
        username:"",
        password:"",
        userType:"1",
      },
      dialogFormVisible:false,
      form:{
        username:"",
        password:"",
        repassword:"",
        phone:"",
        createTime:"",
        money:0,
        status:0,
        createTime: new Date().toLocaleString()
      },
      useradd:{
        username:"",
        password:"",
        phone:"",
        createTime:"",
        money:0,
        status:"",
      }
    });

    //函数
    const login = function () {
      if(data.user.userType == 0){
        http.post("/api/login", data.user).then((res) => {
        if (res.code == 1) {
          sessionStorage.setItem("admin", JSON.stringify(res.data));
          // //登陆后跳转管理员页面
          router.push("/dadmin");
        } else if(res.code == 0) {
          ElMessage({
        message: "该管理员账户未注册!",
        type: "error",
      });
        }
      });
      }else{
        data.user.username=data.user.adminName
        http.post("/api/user/login/user", data.user).then((res) => {
        if (res.code == 1) {
          sessionStorage.setItem("user", JSON.stringify(res.data));
          //登陆后跳转用户页面
          router.push("/duser");
        } else if(res.code == 0) {
          ElMessage({
        message: "用户名或密码错误",
        type: "error",
      });
        }else if(res.code == 2){
          ElMessage({
        message: "该用户已被封号，请联系管理员解封",
        type: "error",
      });
        }
      });
      }
      
    };
    
// 用户注册弹窗
    const add = function(type1){
        data.dialogFormVisible=true      
    };
  //   //处理关闭对话框时数据清理
    const handleClose = () => {
      data.form = {state:1}
      data.dialogFormVisible = false
    }

// 处理用户注册信息
    const saveUser = function(user){
      data.useradd.username = user.username
      data.useradd.password = user.password
      data.useradd.money = 0
      data.useradd.phone = user.phone
      data.useradd.createTime = null
      data.useradd.status = "0"
      if(user.password == user.repassword){
        http.post("/api/user/login/addUser",data.useradd)
      .then(function(res){
        if(res.code == 1){
          data.dialogFormVisible=false,
          data.user.adminName = user.username,
          data.user.password = user.password,
          data.user.userType = "1",
        ElMessage({
        message: "添加成功!",
        type: "success",
      });
        }else if(res.code==2){
          ElMessage({
        message: "该用户已存在",
        type: "error",
      });
        } else{
          ElMessage({
        message: "添加失败!账号不能为空",
        type: "error",
      });
        }
      });
      }else{
        ElMessage({
        message: "两次密码不同，请重新输入",
        type: "error",
      });
      }
      
    }

    return {
       ...toRefs(data), 
       login,
       add,
       handleClose,   
       saveUser
    };
  },
};
</script>

<style scoped>
.login {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f5f5f5;
}

.login-form {
  background: #fff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  max-width: 400px;
  width: 100%;
  text-align: center;
}

.login-form h2 {
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 15px;
  text-align: left;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
}

.form-group input {
  width: calc(100% - 10px);
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.login-button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  border: none;
  border-radius: 5px;
  color: white;
  font-size: 16px;
  cursor: pointer;
}

.login-button:hover {
  background-color: #0056b3;
}
</style>