<template>
  <div style="padding: 15px">
    <!--增加按钮 -->
    <el-button type="success" @click="add">增加用户</el-button>
    <br />
    <br />
    <!--表单 -->
    <el-form :inline="true" :model="searchvo" class="demo-form-inline">
      <el-form-item label="ID">
        <el-input v-model="searchvo.userId" placeholder="精准匹配" clearable />
      </el-form-item>
      <el-form-item label="用户名">
        <el-input v-model="searchvo.username" placeholder="模糊匹配" clearable />
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="load">快捷查询</el-button>
      </el-form-item>
    </el-form>

    <!--表格 -->
    <el-table :data="list" border style="width: 100%">
      <el-table-column type="index" width="80" align="center" label="序号" />
      <el-table-column prop="userId" align="center" label="编号" />
      <el-table-column prop="username" align="center" label="用户名" />
      <el-table-column prop="phone" align="center" label="手机号" />
      <el-table-column prop="money" align="center" label="余额" />
      <el-table-column prop="createTime" align="center" label="创建时间" />
      <el-table-column prop="userStatus" align="center" label="状态">
        <template #default="scope">
          <!-- {{scope.row.state == 1 ? '正常':'异常'}} -->
          <el-button v-if="scope.row.status == 0" style="color: #cccccc" @click="handleUpdateStatus(scope.row)">禁用</el-button>
          <el-button v-if="scope.row.status == 1" style="color: green" @click="handleUpdateStatus(scope.row)">启用</el-button>
         
        </template>
      </el-table-column>
      
      <el-table-column label="操作" align="center">
        <template #default="scope">
          <el-button size="small" @click="show(scope.row)"
            >查看</el-button
          >

          <el-popconfirm
            title="你确定删除么?"
            @confirm="handleDelete(scope.row)"
          >
            <template #reference>
              <el-button size="small" type="danger">删除</el-button>
            </template>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>
    <br />
    <!--分页 -->
    <el-pagination
      background
      v-model:current-page="pageNum"
      :page-sizes="[5, 10, 15, 20]"
      :small="small"
      :disabled="disabled"
     
      layout="prev, pager, next"
      :total="total"
      @current-change="handleCurrentChange"
    />

    <!-- 查看数据的对话框 -->
    <el-dialog
      v-model="dialogFormVisible"
      :title=" '查看'"
      draggable
      @close="handleClose"
    >
      <el-form :model="user" label-width="120px">
        <el-form-item label="手机号">
          {{user.phone}}
        </el-form-item>
        <el-form-item label="用户名">
          {{user.username}}
          <!-- <el-input v-model="form.nikeName" /> -->
        </el-form-item>
        <el-form-item label="余额">
          <!-- <el-input v-model="form.phone" /> -->
           {{user.money}}
        </el-form-item>
        <el-form-item label="创建时间" >
          <el-date-picker
            v-model="user.createTime"
            type="datetime"
            placeholder="请选择时间"
            format="YYYY-MM-DD hh:mm:ss"
            value-format="YYYY-MM-DD hh:mm:ss"
            disabled
          />
        </el-form-item>
        <el-form-item label="账号状态">
          <el-radio-group v-model="user.status">
            <el-radio :label="1" disabled>正常</el-radio>
            <el-radio  :label="0" disabled>禁用</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleClose">取消</el-button>
          
        </span>
      </template>
    </el-dialog>
  
     <!-- 增加数据的对话框 -->
     <el-dialog
      v-model="dialogFormVisibleAdd"
      :title=" '增加用户'"
      draggable
      @close="handleClose"
    >
      <el-form :model="user" label-width="120px">
        <el-form-item label="用户名">
          <el-input v-model="user.username" />
        </el-form-item>
        <el-form-item label="密码">
          <el-input v-model="user.password" show-password />
        </el-form-item>
        <el-form-item label="手机号">
          <el-input v-model="user.phone" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleClose">取消</el-button>
          <el-button type="primary" @click="saveOrUpdate"> 保存 </el-button>
        </span>
      </template>
    </el-dialog>
    
  </div>
</template>
   
   <script>
import { reactive, toRefs } from "vue";
import http from "@/utils/http";
import { ElMessage } from "element-plus";
import axios from "axios";

export default {
  name: "User",
  setup() {
    const data = reactive({
      form: {
        state: 1,
      }, //表单的内容
      list: [], //表格的内容
      total: 10, //分页总条数
      pageNum: 1, //当前页
      pageSize: 5, //初始化每页大小
      dialogFormVisible: false, //对话框的显示和隐藏
      dialogFormVisibleAdd: false,
      user:{},
      searchvo:{
        userId:'',
        username:'',
      }
    });

    //分页查询
    const load = () => {
      http
        .get("/api/user/list/"+data.pageNum, {
          params: {
            userId:data.searchvo.userId,
            username:data.searchvo.username,
          },
        })
        .then(function(res){
      data.list=res.data.list;
      data.pageNum=res.data.pageNum;
      data.total=res.data.total;
        });
    };
     load();//调用加载

    //点击增加按钮
    const add=function(){
      data.dialogFormVisibleAdd = true;
    };
    const saveOrUpdate = function () {
      if(data.user.username==null||data.user.phone==null){
        ElMessage.error("用户名和手机号不能为空")
      }
      else{
        http.post("/api/user/save",data.user).then(function(res){
        data.dialogFormVisibleAdd = false;
        if(res.code==1){
        ElMessage({
        message: "保存成功!",
        type: "success",
      });
      load();
        }
        else{
          ElMessage.error("添加失败,用户名已存在")
        }
      });}
      
    };

    const handleCurrentChange=function(){
      load()
    };
    const handleUpdateStatus=function(row){
      http.get("/api/user/updateuserStatus/"+row.userId+"/"+(row.status==0?1:0)).then(function(res){
        if(res.code==1){
        ElMessage({
        message: "修改成功!",
        type: "success",
      });
      load();
        }
        else{
          ElMessage.error("修改失败")
        }
      })
    };
    const show = function (row) {//row对应list中的json对象
    http
        .get("/api/user/show/"+row.userId)
        .then(function(res){
      data.user=res.data;
        });
    data.dialogFormVisible = true;
      // ElMessage({
      //   message: "保存成功!",
      //   type: "success",
      // });
      //对话框关闭
      
    };
    //删除用户数据
    const handleDelete = function (row) { http.get("/api/user/delete/"+row.userId).then(function(res){
        if(res.code==1){
        ElMessage({
        message: "删除成功!",
        type: "success",
      });
      load();
        }
        else{
          ElMessage.error("删除失败")
        }
      })
    };
    const handleClose=function(){
      data.user={};
      data.dialogFormVisible = false;
      data.dialogFormVisibleAdd= false;
      load();


    };

    return {
      ...toRefs(data),
      load,
      handleClose,
      add,
      show,
      handleCurrentChange,
      handleDelete,
      saveOrUpdate,
      handleUpdateStatus,
    };
  },
};
</script>
   
   <style scoped>
</style>