<template>
  <RouterView></RouterView>
</template>

