<template>
  <div style="width: 200px;">
    <el-menu      default-active="2"      class="el-menu-vertical-demo custom-menu"      router>
      <el-menu-item index="/dadmin/derivative">衍生品信息</el-menu-item>
    </el-menu>
    <el-menu      default-active="2"      class="el-menu-vertical-demo custom-menu"      router>
      <el-menu-item index="/dadmin/user">用户列表</el-menu-item>
    </el-menu>
    <el-menu      default-active="2"      class="el-menu-vertical-demo custom-menu"      router>
      <el-menu-item index="/dadmin/risk">风险实时监控</el-menu-item>
    </el-menu>

  </div>
</template>

<script>


export default {
  name: "Left",
  methods: {
    handleOpen() {
      console.log('open');
    },
    handleClose() {
      console.log('close');
    }
  },
  mounted() {
    const router = this.$router;
    router.beforeEach((to, from, next) => {
      const oldMenuItems = document.querySelectorAll('.el-menu-item.is-active');
      oldMenuItems.forEach((item) => {
        item.classList.remove('is-active');
      });
      next();
    });
}}
</script>

<style scoped>
.custom-menu {
  background: linear-gradient(135deg, #6b73ff 0%, #000dff9f 100%); /* 渐变背景 */
  border-radius: 10px; /* 圆角 */
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* 阴影效果 */
}

.custom-menu .el-menu-item {
  color: #ffffff; /* 字体颜色 */
  font-size: 16px; /* 字体大小 */
  margin: 5px 10px; /* 菜单项间距 */
  border-radius: 5px; /* 菜单项圆角 */
}

.custom-menu .el-menu-item:hover {
  background-color: rgba(255, 255, 255, 0.2); /* 悬停背景 */
  transition: background-color 0.3s; /* 悬停过渡效果 */
}

.custom-menu .el-menu-item.is-active {
  background-color: rgba(255, 255, 255, 0.3); /* 选中背景 */
  color: #ffffff; /* 选中字体颜色 */
  font-weight: bold; /* 选中字体加粗 */
}
</style>
