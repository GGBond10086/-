<template>
  <div class="top" >
    <div class="title">金融衍生品交易系统</div>
    <div style="flex: 1;"></div>
    <div class="welcome">
      <el-dropdown :hide-on-click="false">
    <span class="el-dropdown-link">
      欢迎  
      <span v-if="user != null" >{{user.username}}</span>
      <span v-if="admin != null" >{{admin.adminName}}</span>
        登录<el-icon class="el-icon--right"><arrow-down /></el-icon>
    </span>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item v-if="user.username != null" @click="pay">账户充值</el-dropdown-item>
            <el-dropdown-item @click="logout">退出登录</el-dropdown-item>
            
          </el-dropdown-menu>
        </template>
      </el-dropdown>

      <!-- 用户充值对话框 -->
    <el-dialog
      v-model="userPay"
      :title="'用户充值'"
      draggable
      @close="handleClose"
    >
      <el-form :model="userpay1" label-width="120px">
        <el-form-item label-width="200px" label="当前账户余额(单位:人民币/元)">
          <el-input style="width: 200px;" v-model="userpay1.money" disabled/>
        </el-form-item>
        <el-form-item label-width="200px" label="输入充值金额(单位:人民币/元)">
          <el-input style="width: 200px;" v-model="userpay1.paymoney" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="surepay(userpay1)"> 确认充值 </el-button>
          <el-button @click="handleClose">取消</el-button>
        </span>
      </template>
    </el-dialog>


    </div>


  </div>
</template>

<script>
import {reactive, ref, toRefs} from "vue";
import {useRouter} from "vue-router";
import { ElMessage } from "element-plus";
import http from "@/utils/http";


export default {
  name: "Top",
  setup(){
    const data = reactive({
      user:{},
      userPay:false,
      form:{},
      userpay1:{
        money:"",
        paymoney:"",
      }
    })

  


    //读取存储的用户信息
    let user = sessionStorage.getItem('user');
    if(!(user == null || user == '')){
      // data.admin=null;
      data.user = JSON.parse(user);
    }
    let admin = sessionStorage.getItem('admin');
    if(!(admin == null || admin == '')){
      // data.user=null;
      data.admin = JSON.parse(admin);
    }


    const router = useRouter();

    const logout = () => {
      //清理信息
      sessionStorage.clear()
      //跳转到登录
      router.push("/")
    }
    const logout1 = () => {
      //清理信息
      sessionStorage.clear()
      //跳转到用户信息查询
      router.push("/")
    }
    const pay = function(){
      data.userpay1.money = data.user.money
      data.userPay=true     

    };
    //   //处理关闭对话框时数据清理
    const handleClose = () => {
      data.form = {state:1}
      data.userPay = false
    }
    const surepay = function(pay1){
      if(pay1.paymoney==null){
        ElMessage({
        message: "充值金额不能为空",
        type: "error",
      });
      }else if(+pay1.paymoney>0){
        data.user.money = +pay1.paymoney + +data.user.money
        if(+data.user.money <= 9999999999.99){
          data.userpay1.money = data.user.money
          http.post("/api/user/top/updmoney",data.user)
      .then(function(res){
        if(res.data!=0){
          pay1.paymoney = ""
          data.userPay=false,
        ElMessage({
        message: "充值成功!",
        type: "success",
      });
        }else{
          ElMessage({
        message: "充值失败",
        type: "error",
      });
        }
      });
        }else{
          data.user.money = data.userpay1.money
          ElMessage({
        message: "充值失败，超过单个账户金额存储上限",
        type: "error",
      });
        }
        
      }else{
        ElMessage({
        message: "充值金额格式错误，请输入大于零的数",
        type: "error",
      });
      }
    }
    return {
      ...toRefs(data),
      logout,
      logout1,
      pay,
      handleClose,
      surepay,
    }
  }
}
</script>

<style scoped>
.top{
  background-color: #000dff9f ;
  width: 100%;
  height: 80px;
  display: flex;
}
.title{
  margin-left: 30px;
  font-size: 40px;
  font-weight: bold;
  color: white;
  font-family: 华文楷体;
  justify-content: center;
  align-items: center;
  display: flex;
  text-shadow: 2px 2px #000;
}
.welcome{
  justify-content: center;
  align-items: center;
  color: white;
  width: 150px;
  display: flex;
}
.el-dropdown{
  color: white;
  cursor: pointer;
}
</style>