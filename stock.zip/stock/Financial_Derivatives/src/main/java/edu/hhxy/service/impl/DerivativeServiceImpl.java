package edu.hhxy.service.impl;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import edu.hhxy.domain.Derivative;
import edu.hhxy.service.DerivativeService;
import edu.hhxy.mapper.DerivativeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

/**
* @author Administrator
* @description 针对表【derivative】的数据库操作Service实现
* @createDate 2024-06-20 16:14:04
*/
@Service
public class DerivativeServiceImpl extends ServiceImpl<DerivativeMapper, Derivative>
    implements DerivativeService{
    @Autowired
    DerivativeMapper derivativeMapper;
    @Override
    public List<Derivative> list(Integer page, String derivativeName, String derivativeId) {
        PageHelper.startPage(page,5);
        QueryWrapper<Derivative> queryWrapper=new QueryWrapper<>();
        if(derivativeName!=null&&!"".equals(derivativeName)){
            queryWrapper.like("derivative_name",derivativeName);
        }
        if(derivativeId!=null&&!"".equals(derivativeId)){
            queryWrapper.eq("derivative_id",derivativeId);
        }

        List<Derivative> list=derivativeMapper.selectList(queryWrapper);
        return list;
    }
    @Override
    public List<Derivative> select(String id, String name) {
        QueryWrapper<Derivative> qw=new QueryWrapper<>();
        if(id!=null && !"".equals(id)){
            qw.eq("derivative_id",id);
        }
        if(name!=null && !"".equals(name)){
            qw.like("derivative_name",name);
        }
        return derivativeMapper.selectList(qw);
    }

    @Override
    public boolean removeById(Derivative entity) {
        return super.removeById(entity);
    }

    @Override
    public boolean updateById(Derivative entity) {
        return super.updateById(entity);
    }

    @Override
    public boolean save(Derivative entity) {
        return super.save(entity);
    }
}




