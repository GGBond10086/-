package edu.hhxy.service;

import edu.hhxy.domain.Admin;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @author Administrator
 * @description 针对表【admin】的数据库操作Service
 * @createDate 2024-06-20 16:18:33
 */
public interface AdminService extends IService<Admin> {
    public Admin adminLogin(String adminName,String password);

}
