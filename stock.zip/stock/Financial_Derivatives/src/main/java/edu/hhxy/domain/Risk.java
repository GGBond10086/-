package edu.hhxy.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * 
 * @TableName risk
 */
@TableName(value ="risk")
@Data
public class Risk implements Serializable {
    /**
     * 风险ID
     */
    @TableId(type = IdType.AUTO)
    private Integer riskId;

    /**
     * 衍生品ID
     */
    private Integer derivativeId;

    /**
     * 波动价格
     */
    private BigDecimal riskPrice;

    /**
     * 波动时期
     */
    private Date riskTime;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}