package edu.hhxy.web;

import edu.hhxy.domain.Risk;
import edu.hhxy.domain.RiskDerivativeDTO;
import edu.hhxy.service.RiskService;
import edu.hhxy.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class RiskController {
    @Autowired
    private RiskService riskService;
    @GetMapping("/risk/{name}")
    public Result<List<RiskDerivativeDTO>> risk(@PathVariable String name){
        Result<List<RiskDerivativeDTO>> result=new Result<>();
        result.setData(riskService.selectNatural(name));
        return result;
    }
}
