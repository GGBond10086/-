package edu.hhxy.web;

import edu.hhxy.domain.Admin;
import edu.hhxy.service.AdminService;
import edu.hhxy.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping("/login")
    public Result<Admin> login(@RequestBody Admin admin){
        Result<Admin> result = new Result<>();
        Admin admin1 = adminService.adminLogin(admin.getAdminName(),admin.getPassword());
        if(admin1 != null){
            result.setCode(1);
            result.setData(admin1);
            return result;
        }else {
            result.setCode(0);
        }
        return result;
    }

}
