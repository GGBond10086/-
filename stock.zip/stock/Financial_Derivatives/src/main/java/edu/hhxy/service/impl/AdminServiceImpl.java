package edu.hhxy.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import edu.hhxy.domain.Admin;
import edu.hhxy.service.AdminService;
import edu.hhxy.mapper.AdminMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Administrator
 * @description 针对表【admin】的数据库操作Service实现
 * @createDate 2024-06-20 16:18:33
 */
@Service
public class AdminServiceImpl extends ServiceImpl<AdminMapper, Admin>
        implements AdminService{

    @Autowired
    private AdminMapper adminMapper;

    @Override
    public Admin adminLogin(String adminName, String password) {
        QueryWrapper<Admin> qw = new QueryWrapper<>();
        qw.eq("admin_name",adminName);
        qw.eq("password",password);
        return adminMapper.selectOne(qw);
    }
}




