package edu.hhxy.service;

import edu.hhxy.domain.Derivative;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
* @author Administrator
* @description 针对表【derivative】的数据库操作Service
* @createDate 2024-06-20 16:14:04
*/
public interface DerivativeService extends IService<Derivative> {
    public  List<Derivative> list(Integer page, String VderivativeName, String derivativeId);
    public List<Derivative> select(String id,String name);
}
