package edu.hhxy.domain;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * 用于存储联合查询结果的 DTO 类
 */
@Data
public class RiskDerivativeDTO implements Serializable {
    // Risk 表的字段
    private Integer riskId;
    private Integer derivativeId;
    private BigDecimal riskPrice;
    private Date riskTime;

    // Derivative 表的字段
    private String derivativeName;
    private BigDecimal price;
    private Date createTime;
    private Date updateTime;
    private String type;
    private Integer derivativeQuantity;

    private static final long serialVersionUID = 1L;
}
