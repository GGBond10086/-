package edu.hhxy.web;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import edu.hhxy.domain.Derivative;
import edu.hhxy.domain.Risk;
import edu.hhxy.service.DerivativeService;
import edu.hhxy.service.RiskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import edu.hhxy.utils.Result;
import java.util.List;

@RestController
@RequestMapping("/derivative")
public class DerivativeController {
    @Autowired
    private DerivativeService derivativeService;
    @Autowired
    private RiskService riskService;
    @GetMapping("/list/{page}")
    public Result<PageInfo<Derivative>> list(@PathVariable("page") Integer page,String derivativeName,String derivativeId)
    {
        try {
            List<Derivative> list = derivativeService.list(page, derivativeName, derivativeId);
            PageInfo<Derivative> pv = new PageInfo<>(list);
            Result<PageInfo<Derivative>> result = new Result<>();
            result.setCode(200);
            result.setData(pv);
            result.setMsg("查询成功");
            return result;
        }catch (Exception e){
            Result result = new Result<>();
            result.setCode(500);
            result.setMsg("查询失败");
            return result;
        }

    }
    @GetMapping("/wlist/{pno}")
    public Result<PageInfo<Derivative>> wlist(@PathVariable("pno") Integer pno,String id,String name){
        PageHelper.startPage(pno,10);
        List<Derivative> list=derivativeService.select(id,name);
        PageInfo<Derivative> pv=new PageInfo<>(list);
        Result<PageInfo<Derivative>> result=new Result<>();
        result.setCode(200);
        result.setData(pv);
        return result;
    }

    @GetMapping("/delete/{id}")
    public Result delete(@PathVariable("id") Integer id)
    {try {
        Result result = new Result<>();
        result.setCode(200);
        Boolean res = derivativeService.removeById(id);
        result.setMsg("删除成功");
        return result;
    }catch (Exception e){
        Result result = new Result<>();
        result.setCode(500);
        result.setMsg("删除失败");
        return result;
    }
    }
    @PostMapping("/save")
    public Result save(@RequestBody Derivative derivative)
    {
try {
    Result result = new Result<>();
    result.setCode(200);
    Boolean res = derivativeService.save(derivative);
    result.setMsg("添加成功");
    return result;
}catch (Exception e){
    Result result = new Result<>();
    result.setCode(500);
    result.setMsg("添加失败");
    return result;
}
    }
    @PostMapping("/update")
    public Result update(@RequestBody  Derivative derivative)
    {
    try {

        Risk risk =new Risk();
        risk.setDerivativeId(derivative.getDerivativeId());
        risk.setRiskTime(derivative.getUpdateTime());
        risk.setRiskPrice(derivative.getPrice());
        Boolean ris=riskService.save(risk);
        derivativeService.updateById(derivative);
        Result result=new Result();
        result.setCode(200);
        result.setMsg("更新成功");
        return result;}catch (Exception e){
        Result result=new Result();
        result.setCode(500);
        result.setMsg("更新失败");
        return result;
    }
    }

    @GetMapping("/show/{id}")
    public Result<Derivative> list(@PathVariable("id") String id){
        Result<Derivative> result=new Result<>();
        try {
            Derivative derivative=derivativeService.getById(id);
            result.setCode(200);
            result.setData(derivative);
        }catch (Exception e){
            result.setCode(404);
        }
        return result;
    }

}
