package edu.hhxy.mapper;

import edu.hhxy.domain.Risk;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import edu.hhxy.domain.RiskDerivativeDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
* @author Administrator
* @description 针对表【risk】的数据库操作Mapper
* @createDate 2024-06-20 16:33:27
* @Entity edu.hhxy.domain.Risk
*/
@Mapper
public interface RiskMapper extends BaseMapper<Risk> {
    @Select("SElECT * FROM derivative NATURAL JOIN risk WHERE derivative_name=#{name}")
    List<RiskDerivativeDTO> sen(@Param("name") String name);
}




