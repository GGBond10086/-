package edu.hhxy.service;

import edu.hhxy.domain.Risk;
import com.baomidou.mybatisplus.extension.service.IService;
import edu.hhxy.domain.RiskDerivativeDTO;

import java.util.List;

/**
* @author Administrator
* @description 针对表【risk】的数据库操作Service
* @createDate 2024-06-20 16:33:27
*/
public interface RiskService extends IService<Risk> {
    public List<RiskDerivativeDTO> selectNatural(String name);
}
