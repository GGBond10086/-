package edu.hhxy.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import edu.hhxy.domain.User;
import edu.hhxy.service.UserService;
import edu.hhxy.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Administrator
 * @description 针对表【user】的数据库操作Service实现
 * @createDate 2024-06-20 16:18:33
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>
        implements UserService{

    @Autowired
    private UserMapper userMapper;

    @Override
    public User userLogin(String userName, String password) {
        QueryWrapper<User> qw = new QueryWrapper<>();
        qw.eq("username",userName);
        qw.eq("password",password);
        return userMapper.selectOne(qw);
    }

    @Override
    public int addUser(User user) {
        return userMapper.insert(user);
    }

    @Override
    public int updateUserMoney(User user) {
        return userMapper.updateById(user);
    }
    @Override
    public User userSelect(String username) {
        QueryWrapper<User> qw = new QueryWrapper<>();
        qw.eq("username",username);
        return userMapper.selectOne(qw);
    }

    @Override
    public User selectByName(String username) {
        QueryWrapper<User> qw =new QueryWrapper<>();
        qw.eq("username",username);
        User user=userMapper.selectOne(qw);
        return user;
    }
}




