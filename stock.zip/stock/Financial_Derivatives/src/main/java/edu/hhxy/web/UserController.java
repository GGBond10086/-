package edu.hhxy.web;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import edu.hhxy.domain.Admin;
import edu.hhxy.domain.User;
import edu.hhxy.service.UserService;
import edu.hhxy.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/user")

public class UserController {
    @Autowired
    private UserService userService;
//用户登录
    @PostMapping("/login/user")
    public Result<User> userLogin(@RequestBody User user){
        Result<User> result = new Result<>();
        User user1 = userService.userLogin(user.getUsername(),user.getPassword());
        if(user1 != null){
            if(user1.getStatus() == 0){
                result.setCode(1);
                result.setData(user1);
                return result;
            }else {
                result.setCode(2);
                return result;
            }

        }else {
            result.setCode(0);
            return result;
        }
    }
//用户注册
//用户注册
    @PostMapping("/login/addUser")
    public Result<Integer> addUser1(@RequestBody User user){
//        user.setCreateTime(new Date());
        System.out.println(new Date());
        Result<Integer> result = new Result<>();
        User user1 = userService.userSelect(user.getUsername());
        if(user1 != null){
            result.setCode(2);
            result.setData(0);
        }else{
            if(user.getUsername()!=null&& !Objects.equals(user.getUsername(), "")){
                Integer r = userService.addUser(user);
                result.setCode(1);
                result.setData(r);
            }else {
                result.setCode(0);
                result.setData(0);
            }
        }
        return result;
    }

    //修改用户余额
    @PostMapping("/top/updmoney")
    public Result<Integer> updateUserMoney1(@RequestBody User user){
        Result<Integer> result = new Result<>();
        if(user.getUsername()!=null&& !Objects.equals(user.getUsername(), "")){
            Integer r = userService.updateUserMoney(user);
            result.setCode(1);
            result.setData(r);
        }else {
            result.setCode(0);
            result.setData(0);
        }
        return result;
    }
    @GetMapping("/updateuserStatus/{userId}/{status}")
    public Result update(@PathVariable("userId") Integer userId, @PathVariable("status") Integer status) {
        Result result = new Result();
        try {
            User user = userService.getById(userId);
            user.setStatus(status);
            userService.updateById(user);
            result.setCode(1);

        } catch (Exception e) {
            result.setCode(0);

        }
        return result;
    }

    @GetMapping("/show/{id}")
    public Result<User> show(@PathVariable("id") Integer id) {
        User user = userService.getById(id);
        Result<User> result = new Result<>();
        result.setCode(200);
        result.setData(user);
        return result;
    }

    @GetMapping("/list/{pno}")
    public Result<PageInfo<User>> list(@PathVariable("pno") Integer pno, String userId, String username) {
        PageHelper.startPage(pno, 10);
        System.out.println(userId + '/' + username);
        QueryWrapper<User> qw = new QueryWrapper();
        if (userId != null && !"".equals(userId)) {
            qw.eq("user_id", userId);
        }
        if (username != null && !"".equals(username)) {
            qw.like("username", username);
        }
        List<User> list = userService.list(qw);
        PageInfo<User> pv = new PageInfo<>(list);
        Result<PageInfo<User>> result = new Result<>();
        result.setCode(200);
        result.setData(pv);
        return result;
    }

    @GetMapping("/delete/{id}")
    public Result save(@PathVariable("id") Integer id) {
        Result result = new Result();
        try {
            userService.removeById(id);
            result.setCode(1);

        } catch (Exception e) {
            result.setCode(0);

        }
        return result;
    }
    @PostMapping("/update")
    public Result update(@RequestBody User user) {
        Result result = new Result();
        try {
//        User user = userService.getById(user.getUserId());
//        user.setUsername(username);
//        user.setPassword(password);
            userService.updateById(user);
            result.setCode(1);
            return result;
        } catch (Exception e) {
            result.setCode(0);
            return result;
        }
    }
    @PostMapping("/save")

    public Result save(@RequestBody User userinfo) {

        Result result = new Result();
        User user1 = userService.selectByName(userinfo.getUsername());
        if (user1 == null) {
            try {

                userinfo.setStatus(0);
                userinfo.setCreateTime(new Date());
                userService.save(userinfo);
                result.setCode(1);
                return result;
            } catch (Exception e) {
                result.setCode(0);
                return result;
            }
        } else {
            result.setCode(0);
            return result;
        }

    }
}
