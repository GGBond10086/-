import jieba
import joblib
from sklearn.metrics.pairwise import linear_kernel

import DbUtil
from sklearn.feature_extraction.text import TfidfVectorizer
db=DbUtil.DbUtil()
def train():
    books=[]
    bookdesc=db.findallgood()
    for book in bookdesc:
        words=jieba.lcut(book)
        words=" ".join(words)
        books.append(words)
    tfidf=TfidfVectorizer()
    tensor=tfidf.fit_transform(books)
    cos=linear_kernel(tensor)
    with open('book.pkl','wb') as f:
        joblib.dump(cos,f)
def predict(id):
    with open('book.pkl','rb') as f:
        model=joblib.load(f)
    book=model[id-1]
    book2=enumerate(book)
    book2=sorted(book2,key=lambda x:x[1],reverse=True)
    top5=book2[1:6]
    top5ids=map(lambda x:x[0]+1,top5)
    result=[]
    for i in top5ids:
        bk=db.findone(i)
        result.append(bk)
    return result





if __name__=='__main__':
    train()
