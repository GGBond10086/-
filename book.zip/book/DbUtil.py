import pymongo
import random


class DbUtil:
    def __init__(self):
        self.conn = pymongo.MongoClient('localhost', 27017)
        self.db = self.conn['books']
        self.col = self.db['book']

    def insertion(self, book):
        self.col.insert_many(book)
    def findall(self):
        result=[]
        cur= self.col.find({},{'_id':0})
        for i in cur:
            result.append(i)
        return result
    def findallgood(self):
        result=[]
        cur= self.col.find({},{'desc':1,'_id':0})
        for i in cur:
            result.append(i['desc'])
        return result
    def findone(self, bookid):
        cur= self.col.find({'id':bookid},{'_id':0})
        for i in cur:
            return i

    # result = collection.insert_many([student2,student3])
    # print(result)
    # print(result.inserted_ids)
    ##查询
    # result = collection.find_one({'age':21})
    # print(result)
    # results = collection.find({'name':'Guo'})
    # for result in results:
    #     print(result)
    # results = collection.find({'age':{'$gt':21}})  ##age大于21
    # for result in results:
    #     print(result)
    ##排序
    # results = collection.find().sort('id',pymongo.ASCENDING)
    # print([result['name'] for result in results])
    ##更新
    # condition = {'name':'qian'}
    # result = collection.update_many(condition,{'$set':{'age':88,'name':'tang'}})
    # print(result)
    # print(result.matched_count,result.modified_count)
    ##删除
    # result = collection.delete_one({'name':'li'})
    # print(result)
    # print(result.deleted_count)

    # db = client.books
    # collection = db.books
    #
    # results = collection.find()
    # count = 0
    # for i in results:
    #     print(count,i.get('name'))
    #     count += 1
    # print(count)
