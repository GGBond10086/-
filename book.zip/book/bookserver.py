from flask import Flask, request
from flask import render_template
import DbUtil
from goodidea import predict

db = DbUtil.DbUtil()
books = db.findall()
app = Flask(__name__)


@app.route("/")
def index():
    return render_template('booklist.html', books=books)


@app.route("/todatail", methods=['GET', 'POST'])
def todatail():
    id = request.args["id"]
    bookdata = db.findone(int(id))
    top5 = predict(int(id))
    return render_template('todatail.html', book=bookdata, data=top5)


if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5000)
