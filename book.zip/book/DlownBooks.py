import numpy as np
import requests
import DbUtil

def DlownBooks(page, start_id):
    start = page * 100
    url = f"http://e.dangdang.com/media/api.go?action=mediaCategoryLeaf&promotionType=1&deviceSerialNo=html5&macAddr=html5&channelType=html5&permanentId=20240516092838175320613769162215755&returnType=json&channelId=70000&clientVersionNo=6.8.0&platformSource=DDDS-P&fromPlatform=106&deviceType=pconline&token=&start={start}&end={start+99}&category=XS2&dimension=dd_sale"
    req = requests.get(url)
    req.encoding = "utf-8"
    rew = req.json()
    books = rew["data"]["saleList"]
    bookdatas = []

    for index, book in enumerate(books, start=start_id):
        Book = {}
        bookdata = book["mediaList"][0]
        Book['id'] = index
        Book["title"] = bookdata["title"]
        Book["price"] = bookdata["salePrice"]
        Book["author"] = bookdata["authorPenname"]
        Book["image"] = bookdata["coverPic"]
        Book["desc"] = bookdata["descs"]
        bookdatas.append(Book)

    return bookdatas

if __name__ == "__main__":
    start_id = 1  # 设置起始ID
    for page in range(0, 1000):
        books = DlownBooks(page, start_id)
        db = DbUtil.DbUtil()
        db.insertion(books)
        start_id += len(books)  # 更新起始ID
